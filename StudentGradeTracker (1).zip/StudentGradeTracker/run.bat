@echo off
if not exist out mkdir out
javac -d out src\Student.java src\StudentGradeTracker.java
if errorlevel 1 (
    echo Compilation failed.
    pause
    exit /b 1
)
java -cp out StudentGradeTracker
pause
