public class Student {
    private final int rollNo;
    private final String name;
    private final double[] grades;

    public Student(int rollNo, String name, double[] grades) {
        this.rollNo = rollNo;
        this.name = name;
        this.grades = grades.clone();
    }

    public int getRollNo() { return rollNo; }
    public String getName() { return name; }
    public double[] getGrades() { return grades.clone(); }

    public double average() {
        double sum = 0;
        for (double grade : grades) sum += grade;
        return grades.length == 0 ? 0 : sum / grades.length;
    }

    public double highest() {
        double max = Double.NEGATIVE_INFINITY;
        for (double grade : grades) max = Math.max(max, grade);
        return grades.length == 0 ? 0 : max;
    }

    public double lowest() {
        double min = Double.POSITIVE_INFINITY;
        for (double grade : grades) min = Math.min(min, grade);
        return grades.length == 0 ? 0 : min;
    }
}
