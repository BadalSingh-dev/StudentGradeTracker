import java.util.ArrayList;
import java.util.Scanner;

public class StudentGradeTracker {
    private static final Scanner scanner = new Scanner(System.in);
    private static final ArrayList<Student> students = new ArrayList<>();

    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("       STUDENT GRADE TRACKER");
        System.out.println("========================================");

        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1 -> addStudent();
                case 2 -> displayAllStudents();
                case 3 -> displayClassStatistics();
                case 4 -> searchStudent();
                case 5 -> removeStudent();
                case 6 -> {
                    running = false;
                    System.out.println("\nThank you for using Student Grade Tracker!");
                }
                default -> System.out.println("Invalid choice. Please try again.\n");
            }
        }
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n------------- MENU -------------");
        System.out.println("1. Add Student");
        System.out.println("2. Display Summary Report");
        System.out.println("3. Display Class Statistics");
        System.out.println("4. Search Student");
        System.out.println("5. Remove Student");
        System.out.println("6. Exit");
        System.out.println("--------------------------------");
    }

    private static void addStudent() {
        System.out.println("\n--- Add Student ---");
        int rollNo = readInt("Enter roll number: ");
        if (findStudent(rollNo) != null) {
            System.out.println("A student with this roll number already exists.\n");
            return;
        }

        System.out.print("Enter student name: ");
        String name = scanner.nextLine().trim();
        while (name.isEmpty()) {
            System.out.print("Name cannot be empty. Enter name: ");
            name = scanner.nextLine().trim();
        }

        int subjectCount = readInt("Enter number of subjects: ");
        while (subjectCount <= 0) {
            System.out.println("Number of subjects must be greater than 0.");
            subjectCount = readInt("Enter number of subjects: ");
        }

        double[] grades = new double[subjectCount];
        for (int i = 0; i < subjectCount; i++) {
            grades[i] = readGrade("Enter grade for subject " + (i + 1) + " (0-100): ");
        }

        students.add(new Student(rollNo, name, grades));
        System.out.println("Student added successfully.\n");
    }

    private static void displayAllStudents() {
        System.out.println("\n================ SUMMARY REPORT ================");
        if (students.isEmpty()) {
            System.out.println("No student records available.");
            return;
        }

        System.out.printf("%-8s %-22s %-10s %-10s %-10s %-10s%n",
                "Roll No", "Name", "Average", "Highest", "Lowest", "Result");
        System.out.println("--------------------------------------------------------------");
        for (Student student : students) {
            System.out.printf("%-8d %-22s %-10.2f %-10.2f %-10.2f %-10s%n",
                    student.getRollNo(), student.getName(), student.average(),
                    student.highest(), student.lowest(), result(student.average()));
        }
        System.out.println("==============================================================");
    }

    private static void displayClassStatistics() {
        if (students.isEmpty()) {
            System.out.println("\nNo student records available.");
            return;
        }

        double totalAverage = 0;
        double highestScore = Double.NEGATIVE_INFINITY;
        double lowestScore = Double.POSITIVE_INFINITY;
        String highestStudent = "";
        String lowestStudent = "";

        for (Student student : students) {
            totalAverage += student.average();
            if (student.highest() > highestScore) {
                highestScore = student.highest();
                highestStudent = student.getName();
            }
            if (student.lowest() < lowestScore) {
                lowestScore = student.lowest();
                lowestStudent = student.getName();
            }
        }

        System.out.println("\n========== CLASS STATISTICS ==========");
        System.out.printf("Number of students : %d%n", students.size());
        System.out.printf("Class average      : %.2f%n", totalAverage / students.size());
        System.out.printf("Highest score      : %.2f (%s)%n", highestScore, highestStudent);
        System.out.printf("Lowest score       : %.2f (%s)%n", lowestScore, lowestStudent);
        System.out.println("======================================");
    }

    private static void searchStudent() {
        System.out.println("\n--- Search Student ---");
        int rollNo = readInt("Enter roll number: ");
        Student student = findStudent(rollNo);
        if (student == null) {
            System.out.println("Student not found.\n");
            return;
        }
        System.out.println("Name     : " + student.getName());
        System.out.println("Roll No  : " + student.getRollNo());
        System.out.printf("Average  : %.2f%n", student.average());
        System.out.printf("Highest  : %.2f%n", student.highest());
        System.out.printf("Lowest   : %.2f%n", student.lowest());
        System.out.println("Result   : " + result(student.average()));
    }

    private static void removeStudent() {
        System.out.println("\n--- Remove Student ---");
        int rollNo = readInt("Enter roll number: ");
        Student student = findStudent(rollNo);
        if (student == null) {
            System.out.println("Student not found.\n");
            return;
        }
        students.remove(student);
        System.out.println("Student removed successfully.\n");
    }

    private static Student findStudent(int rollNo) {
        for (Student student : students) {
            if (student.getRollNo() == rollNo) return student;
        }
        return null;
    }

    private static String result(double average) {
        return average >= 40 ? "PASS" : "FAIL";
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }

    private static double readGrade(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                double grade = Double.parseDouble(input);
                if (grade >= 0 && grade <= 100) return grade;
                System.out.println("Grade must be between 0 and 100.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
