# Student Grade Tracker

A console-based Java application to input and manage student grades.

## Features
- Add multiple students using an `ArrayList`.
- Store each student's subject grades using an array.
- Calculate average, highest, and lowest scores.
- Display a complete student summary report.
- Display class-level statistics.
- Search a student by roll number.
- Remove a student by roll number.
- Input validation for roll numbers and grades (0-100).
- Pass/Fail result based on a 40% average.

## Requirements
- Java JDK 14+ (uses modern switch syntax).
- Command Prompt / PowerShell / Terminal.

## Run
From the project folder:

```text
javac -d out src\\Student.java src\\StudentGradeTracker.java
java -cp out StudentGradeTracker
```

### Windows PowerShell
```powershell
javac -d out src\Student.java src\StudentGradeTracker.java
java -cp out StudentGradeTracker
```

## Project Structure
```text
StudentGradeTracker/
├── src/
│   ├── Student.java
│   └── StudentGradeTracker.java
└── README.md
```

## Assignment Requirements Covered
- Java program to input and manage student grades: **Yes**
- Average, highest and lowest scores: **Yes**
- Arrays / ArrayList for data management: **Yes**
- Summary report of all students: **Yes**
- Console-based interface: **Yes**
